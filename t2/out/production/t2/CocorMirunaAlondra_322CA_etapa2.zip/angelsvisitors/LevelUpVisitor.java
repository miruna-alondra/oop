package angelsvisitors;

import angels.LevelUpAngel;
import constants.Constants;
import heroes.Knight;
import heroes.Pyromancer;
import heroes.Rogue;
import heroes.Wizard;

import java.util.ArrayList;
import java.util.List;

public final class LevelUpVisitor implements AngelVisitor {
    private LevelUpAngel angel;
    private List<Float> raceModif = new ArrayList<>();

    public LevelUpVisitor(final LevelUpAngel levelUpAngel) {
        angel = levelUpAngel;
    }

    // Schimb modificatorii de rasa ai fiecarui jucator
    @Override
    public void visit(final Knight k) {
        for (int i = 0; i < Constants.NO_POWERS; i++) {
            raceModif.add(k.getRaceModif().get(i) + Constants.LEVEL_UP_HIGH_DMG_KNIGHT);
        }
        k.setRaceModif(raceModif);
    }

    @Override
    public void visit(final Pyromancer p) {
        for (int i = 0; i < Constants.NO_POWERS; i++) {
            raceModif.add(p.getRaceModif().get(i) + Constants.LEVEL_UP_HIGH_DMG_PYRO);
        }
        p.setRaceModif(raceModif);
    }

    @Override
    public void visit(final Rogue r) {
        for (int i = 0; i < Constants.NO_POWERS; i++) {
            raceModif.add(r.getRaceModif().get(i) + Constants.LEVEL_UP_HIGH_DMG_ROGUE);
        }
        r.setRaceModif(raceModif);
    }

    @Override
    public void visit(final Wizard w) {
        for (int i = 0; i < Constants.NO_POWERS; i++) {
            raceModif.add(w.getRaceModif().get(i) + Constants.LEVEL_UP_HIGH_DMG_WIZARD);
        }
        w.setRaceModif(raceModif);
    }
}
