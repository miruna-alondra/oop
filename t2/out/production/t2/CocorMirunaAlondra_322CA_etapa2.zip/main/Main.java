package main;

import angels.Status;
import fileio.implementations.FileWriter;
import heroes.Hero;
import heroes.HeroFactory;
import input.GameInput;
import input.GameInputLoader;
import input.Position;
import map.FieldSingleton;
import observer.Magician;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public final class Main {

    private static FileWriter fs;

    public static FileWriter getFs() {
        return fs;
    }

    public void setFs(final FileWriter fs) {
        this.fs = fs;
    }

    // printeaza actiunea ingerului asupra eroului in functie de statusul
    // ingerului
    private static void printHelp(final int k, final GameInput gameInput,
                                  final FileWriter fileWriter, final List<Hero> heroes) {
        for (int s = 0; s < gameInput.getNoHeroes(); s++) {
           // fileWriter.writeWord(gameInput.getAngels().get(k).getAngelName());
            try {
                fileWriter.writeWord(gameInput.getAngels().get(k).getAngelName());
                if (gameInput.getAngels().get(k).getStatus().equals(Status.GOOD)) {
                    fileWriter.writeWord("helped ");
                    fileWriter.writeWord(heroes.get(s).getName());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(s).getId());
                    fileWriter.writeNewLine();
                } else {
                    fileWriter.writeWord("hit ");
                    fileWriter.writeWord(heroes.get(s).getName());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(s).getId());
                    fileWriter.writeNewLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // printeaza daca eroul a fost ucis de un erou
    private static void printKilled(final GameInput gameInput, final FileWriter fileWriter,
                                    final List<Hero> heroes) {
        for (int s = 0; s < gameInput.getNoHeroes(); s++) {
            try {
                fileWriter.writeWord(gameInput.getAngels().get(0).getAngelName());
                fileWriter.writeWord(" ");
                fileWriter.writeWord("hit ");
                fileWriter.writeWord(heroes.get(s).getName());
                fileWriter.writeWord(" ");
                fileWriter.writeInt(heroes.get(s).getId());
                fileWriter.writeNewLine();
                fileWriter.writeWord(heroes.get(s).getName());
                fileWriter.writeWord(" ");
                fileWriter.writeInt(s);
                fileWriter.writeWord(" ");
                fileWriter.writeWord("was killed by an angel");
                fileWriter.writeNewLine();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // afiseaza rezultatele in urma luptei
    private static void printResults(final List<Hero> heroes, final FileWriter fileWriter) {
        for (int i = 0; i < heroes.size(); i++) {
            try {
                if (heroes.get(i).getCurrentHp() > 0) {
                    fileWriter.writeCharacter(heroes.get(i).getName().charAt(0));
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(i).getLevel());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(i).getXp());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(i).getCurrentHp());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(i).getP().getX());
                    fileWriter.writeWord(" ");
                    fileWriter.writeInt(heroes.get(i).getP().getY());
                    fileWriter.writeNewLine();
                } else {
                    fileWriter.writeCharacter(heroes.get(i).getName().charAt(0));
                    fileWriter.writeWord(" dead");
                    fileWriter.writeNewLine();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private Main() {
    }
    public static void main(final String[] args) throws IOException {

         //Citesc datele din fisierul de intrare (args[0]) si
         //construiesc jocul.

        GameInputLoader gameInputLoader = new GameInputLoader(args[0], args[1]);
        GameInput gameInput = gameInputLoader.load();
        HeroFactory factory = HeroFactory.getInstance();
        int rounds = gameInput.getRounds();
        List<Hero> heroesNames = gameInput.getHeroes();
        List<Hero> heroes = new ArrayList<>();
        FieldSingleton field = FieldSingleton.getInstance();
        field.init(gameInput.getNameFields());
        String filename = args[1];
        FileWriter fileWriter = new FileWriter(filename);
        Magician magician = new Magician();


         //  Creez jucatorii folosind factory.
        for (int i = 0; i < gameInput.getNoHeroes(); i++) {
            Position p = heroesNames.get(i).getP();
            String name = heroesNames.get(i).getName();
            Hero h = factory.getHero(name, p);
            heroes.add(h);
        }

         // Se vor ataca jucatorii in functie de numarul de runde

        // daca eroul a fost omorat in prima runda de catre
        // primul jucator din lista va deveni 1
        int killedBy1Round1 = 0;
        // daca eroul a fost omorat in prima runda de catre
        // al doilea jucator din lista va deveni 1
        int killedBy2Round1 = 0;
        // daca eroul a fost omorat in a doua runda de catre
        // primul jucator va deveni 1
        int killedBy1Round2 = 0;
        // daca eroul a fost omorat in a doua runda de catre
        // primul jucator va deveni 1
        int killedBy2Round2 = 0;
        // daca eroul a fost omorat de un inger va deveni 1
        int killedByAngel1 = 0;
        // daca eroul a fost omorat de un inger va deveni 1
        int killedByAngel2 = 0;
        int j = 0;

        for (int i = 0; i < rounds; i++) {
            Hero h1 = heroes.get(0);
            h1.setId(0);
            Hero h2 = heroes.get(1);
            h2.setId(1);
            h1.applyStrategy();
            h2.applyStrategy();

            // Verific daca vreunul dintre jucatorii ofera
            // damage overtime
            if (h1.getDamageOvertime().getTime() != 0) {
                h1.getDamageOvertime().setTime(h1.getDamageOvertime().getTime() - 1);
                h1.setCurrentHp(h1.getCurrentHp() - h1.getDamageOvertime().getDmg());
            }

            if (h2.getDamageOvertime().getTime() != 0) {
                h2.getDamageOvertime().setTime(h2.getDamageOvertime().getTime() - 1);
                h2.setCurrentHp(h2.getCurrentHp() - h2.getDamageOvertime().getDmg());
            }

            // verific daca a murit vreunul dintre jucatori
            // si actualizez xp-ul castigatorului
            if (h1.getCurrentHp() > 0 && h2.getCurrentHp() > 0) {
                h1.attack(h2);
                h2.attack(h1);
                if (h1.getCurrentHp() <= 0 && i == 0) {
                    h2.updateXp(h1);
                    killedBy1Round1 = 1;
                } else if (h1.getCurrentHp() <= 0 && i == 1) {
                    h2.updateXp(h1);
                    killedBy1Round2 = 1;
                }
                if (h2.getCurrentHp() <= 0 && i == 0) {
                    h1.updateXp(h2);
                    killedBy2Round1 = 1;
                } else if (h2.getCurrentHp() <= 0 && i == 1) {
                    h1.updateXp(h2);
                    killedBy2Round2 = 1;
                }
            }


            if (gameInput.getNoAngelsperRound().get(i) >  0) {
                gameInput.getAngels().get(j).save(h1);
                if (h1.getCurrentHp() <= 0) {
                    killedByAngel1 = 1;
                }
                gameInput.getAngels().get(j).save(h2);
                if (h1.getCurrentHp() <= 0) {
                    killedByAngel2 = 1;
                }
                j++;
            }
        }
        int k = 0;
        heroes.get(0).addObserver(magician);
        heroes.get(1).addObserver(magician);
        gameInput.getAngels().get(0).addObserver(magician);

        // Realizez scrierea in fisier a output-ului
        for (int i = 1; i < rounds + 1; i++) {
            fileWriter.writeWord("~~ Round ");
            fileWriter.writeInt(i);
            fileWriter.writeWord(" ~~");
            fileWriter.writeNewLine();
            if (gameInput.getNoAngelsperRound().get(i - 1) == 0) {
                if (heroes.get(0).getCurrentHp() <= 0) {
                    String message = heroes.get(0).killedByHero(heroes.get(1));
                    heroes.get(0).update(message);
                }
                if (heroes.get(1).getCurrentHp() <= 0) {
                    String message = heroes.get(1).killedByHero(heroes.get(0));
                    heroes.get(1).update(message);
                }
            } else if (heroes.get(0).getCurrentHp() <= 0) {
                String message = heroes.get(0).killedByAngel();
                heroes.get(0).update(message);
            }

            if (gameInput.getNoAngelsperRound().get(k) > 0) {
                for (int l = 0; l < gameInput.getNoAngelsperRound().get(k); l++) {
                    fileWriter.writeWord("Angel " + gameInput.getAngels().get(l).getAngelName()
                    + " was spawned at " + gameInput.getAngels().get(l).getPosition().getX());
                    fileWriter.writeWord(" " + gameInput.getAngels().get(l).getPosition().getY());
                    fileWriter.writeNewLine();
                    if (killedBy1Round1 == 0 && killedBy1Round2 == 0
                            && killedBy2Round1 == 0 && killedBy2Round2 == 0
                            && killedByAngel1 != 1 && killedByAngel2 != 1) {
                        printHelp(k, gameInput, fileWriter, heroes);
                    } else if (killedBy1Round1 == 0 && killedBy1Round2 == 0 && killedBy2Round1 == 0
                            && killedBy2Round2 == 0) {
                        printKilled(gameInput, fileWriter, heroes);
                    }
                }
            }
            k++;
            fileWriter.writeNewLine();
        }

                fileWriter.writeWord("~~ Results ~~");
                fileWriter.writeNewLine();
                printResults(heroes, fileWriter);

        fileWriter.close();

    }
}
