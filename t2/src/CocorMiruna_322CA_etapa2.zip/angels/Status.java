package angels;

public enum Status {
    GOOD, BAD;
}
